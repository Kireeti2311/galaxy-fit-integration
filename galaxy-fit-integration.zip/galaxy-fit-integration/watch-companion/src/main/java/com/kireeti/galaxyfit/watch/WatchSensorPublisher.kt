package com.kireeti.galaxyfit.watch

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Runs on the watch. Reads live sensor values (heart rate, accelerometer,
 * etc.) via the Samsung Health Sensor SDK's watch-side tracking APIs and
 * publishes them to the paired phone app.
 *
 * The phone<->watch transport itself is typically handled by the SDK's own
 * connection layer (it manages the Bluetooth channel), so in most setups you
 * don't need to hand-roll a MessageClient/DataClient bridge — confirm this
 * against the current SDK docs, since transport details have changed across
 * SDK versions.
 */
class WatchSensorPublisher : Service() {

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification())
        startSensorReadings()
    }

    private fun startSensorReadings() {
        // ---- TODO: Replace with real Samsung Health Sensor SDK calls ----
        //
        //   val trackingService = HealthTrackingService(connectionListener, applicationContext)
        //   trackingService.connectService()
        //
        //   // in onConnectionSuccess:
        //   val tracker = trackingService.getHealthTracker(HealthTrackerType.HEART_RATE_CONTINUOUS)
        //   tracker.setEventListener(...)  // same pattern as phone-side stub
        //
        // On the watch side the SDK generally handles pushing data to the
        // connected phone app automatically once both sides are set up —
        // check the "Companion Device" section of the SDK docs for the exact
        // pairing handshake required between this app and phone-app.
        // -------------------------------------------------------------------
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification {
        val channel = NotificationChannel(
            CHANNEL_ID, "Sensor Publishing", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Fit Stream Companion")
            .setContentText("Streaming sensor data to phone")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 43
        private const val CHANNEL_ID = "sensor_publish"
    }
}
