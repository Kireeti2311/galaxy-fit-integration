package com.kireeti.galaxyfit.watch

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.wear.activity.WearableActivity

class WatchMainActivity : WearableActivity() {

    private val statusView by lazy { TextView(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(statusView)
        statusView.text = "Fit Stream Companion"

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BODY_SENSORS)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startPublisher()
        } else {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.BODY_SENSORS), SENSOR_PERMISSION_CODE
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == SENSOR_PERMISSION_CODE &&
            grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        ) {
            startPublisher()
        } else {
            statusView.text = "Sensor permission denied."
        }
    }

    private fun startPublisher() {
        statusView.text = "Streaming to phone…"
        ContextCompat.startForegroundService(this, Intent(this, WatchSensorPublisher::class.java))
    }

    companion object {
        private const val SENSOR_PERMISSION_CODE = 2001
    }
}
