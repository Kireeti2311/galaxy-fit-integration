package com.kireeti.galaxyfit.phone

import android.content.Context

/**
 * Wraps the Samsung Health Sensor SDK's connection lifecycle to the watch
 * companion app. Kept separate from SensorStreamService so connection
 * handling and sensor-subscription logic don't get tangled.
 */
class ConnectionManager(private val context: Context) {

    fun connect(
        onConnected: () -> Unit,
        onDisconnected: () -> Unit,
        onError: (Throwable) -> Unit
    ) {
        // TODO: Replace with real SDK connection setup, e.g.:
        //
        //   val connectionListener = object : ConnectionListener {
        //       override fun onConnectionSuccess() = onConnected()
        //       override fun onConnectionEnded() = onDisconnected()
        //       override fun onConnectionFailed(error: HealthTrackerException) =
        //           onError(error)
        //   }
        //   healthTrackingService = HealthTrackingService(connectionListener, context)
        //   healthTrackingService.connectService()
        //
        // Common failure to handle explicitly: watch companion app not
        // installed/paired yet — the SDK surfaces this as a specific error
        // code, worth a distinct UI message ("Install companion app on watch").
    }

    fun disconnect() {
        // TODO: healthTrackingService.disconnectService()
    }
}
