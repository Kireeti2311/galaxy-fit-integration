package com.kireeti.galaxyfit.phone

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService

/**
 * Foreground service that owns the connection to the watch companion app and
 * the live sensor subscriptions. Runs as a foreground service because sensor
 * streaming needs to survive the phone screen turning off / app backgrounding.
 *
 * Wire the actual Samsung Health Sensor SDK calls in where marked below.
 * SDK docs: Samsung developer portal > Health > Health Sensor SDK.
 */
class SensorStreamService : LifecycleService() {

    private val connectionManager by lazy { ConnectionManager(applicationContext) }

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification())
        connectionManager.connect(
            onConnected = { startSensorSubscriptions() },
            onDisconnected = { /* TODO: retry/backoff, update UI state */ },
            onError = { error -> /* TODO: surface error, e.g. watch app not installed */ }
        )
    }

    private fun startSensorSubscriptions() {
        // ---- TODO: Replace with real Samsung Health Sensor SDK calls ----
        //
        // Typical shape (from SDK docs), once the AAR dependency is added:
        //
        //   val trackingService = HealthTrackingService(connectionListener, applicationContext)
        //   trackingService.connectService()
        //
        //   // inside the connection listener's onConnectionSuccess callback:
        //   val heartRateTracker = trackingService.getHealthTracker(
        //       HealthTrackerType.HEART_RATE_CONTINUOUS
        //   )
        //   heartRateTracker.setEventListener(object : HealthTracker.TrackerEventListener {
        //       override fun onDataReceived(dataPoints: List<DataPoint>) {
        //           dataPoints.forEach { point ->
        //               val bpm = point.getValue(ValueKey.HeartRateSet.HEART_RATE)
        //               onSensorSample(SensorSample(type = "heart_rate", value = bpm.toDouble()))
        //           }
        //       }
        //       override fun onFlushCompleted() {}
        //       override fun onError(error: HealthTracker.TrackerError) {
        //           // e.g. PERMISSION_ERROR if partner approval missing for this sensor
        //       }
        //   })
        //
        // Repeat the getHealthTracker(...) + setEventListener(...) pattern for
        // each additional sensor type you have approval for (accelerometer,
        // SpO2, etc — check HealthTrackerType for the full enum).
        // -------------------------------------------------------------------
    }

    private fun onSensorSample(sample: SensorSample) {
        // TODO: forward into your processing/agent pipeline —
        // e.g. emit on a Flow, write to a local buffer, push to a ViewModel.
    }

    override fun onDestroy() {
        connectionManager.disconnect()
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }

    private fun buildNotification(): Notification {
        val channel = NotificationChannel(
            CHANNEL_ID, "Sensor Streaming", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Galaxy Fit Stream")
            .setContentText("Receiving live sensor data")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 42
        private const val CHANNEL_ID = "sensor_stream"
    }
}

data class SensorSample(
    val type: String,
    val value: Double,
    val timestampMillis: Long = System.currentTimeMillis()
)
