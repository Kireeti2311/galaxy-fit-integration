# Galaxy Fit Real-Time Sensor Integration — Starter Skeleton

Two-module skeleton for streaming live sensor data (heart rate, accelerometer, etc.)
from a Galaxy Fit / Galaxy Watch device to a phone app in real time, using the
**Samsung Health Sensor SDK**.

## Structure

```
galaxy-fit-integration/
├── phone-app/       Android app that runs on the phone, receives streamed data
└── watch-companion/ Companion app that runs on the watch, reads sensors and pushes data
```

## Before this code will run

1. **Register as a Samsung developer** at https://developer.samsung.com and create
   an app entry for Health.
2. **Download the Samsung Health Sensor SDK** (AAR/JAR + docs) from the Samsung
   developer portal — it is NOT on Maven Central, so it must be added manually
   as a local dependency in both modules' `build.gradle`.
3. **Check sensor approval status.** Heart rate is generally available without
   extra approval; raw PPG / accelerometer streams may require applying for
   partner-level access via the portal. Confirm this for whichever exact
   signals you listed (you said "all" — verify each one individually).
4. **Confirm your Galaxy Fit model's platform.** Newer Galaxy Watch/Fit devices
   run Wear OS (Samsung's One UI Watch); the Health Sensor SDK's watch-side
   APIs differ slightly between older Tizen models and Wear OS. The
   `watch-companion` module here is stubbed for Wear OS — flag your exact
   model and I'll adjust if it's an older Tizen device.
5. Place the SDK's `.aar`/`.jar` in each module's `libs/` folder and reference
   it in `build.gradle` (`implementation files('libs/healthsensor.aar')`).

## What's stubbed vs. real

- Gradle structure, manifests, and permission handling: ready to build against
- The actual `HealthTrackerCapability` subscription calls: stubbed with
  `TODO` markers and comments showing the exact SDK call shape, since the SDK
  itself can't be bundled here (Samsung-licensed, not redistributable)
- Bluetooth pairing/connection-manager boilerplate: sketched in
  `ConnectionManager.kt`, using the SDK's `ConnectionListener` pattern

## Building without a computer (GitHub Actions)

This project includes `.github/workflows/build.yml`, which builds both debug
APKs automatically on GitHub's servers whenever you push to `main` — no local
Android Studio or Gradle needed. All of this can be done from a phone browser
or the GitHub mobile app:

1. Create a free GitHub account if you don't have one, and create a new
   **public or private repo** (e.g. `galaxy-fit-integration`).
2. Upload this project's contents into that repo. Easiest way from a phone:
   GitHub's web/app upload UI lets you drag/select files — upload the whole
   extracted folder, or use GitHub's "Upload files" and select everything at
   once, preserving the folder structure.
3. Once pushed, go to the repo's **Actions** tab — a "Build APKs" run should
   start automatically (or tap **Run workflow** to trigger it manually).
4. When the run finishes (green check), open it and scroll to
   **Artifacts** at the bottom — you'll see `phone-app-debug` and
   `watch-companion-debug` as downloadable zips containing the APKs.
5. Download each, extract the `.apk`, and transfer it to the right device:
   - `phone-app-debug` → your phone. Open the APK file from your phone's
     downloads/file manager to install it (you'll need to allow "install
     unknown apps" for the browser/file-manager app you use).
   - `watch-companion-debug` → the Galaxy Fit. Direct APK install on a watch
     from a phone file manager isn't straightforward without ADB — likely
     easiest path is installing a lightweight APK-installer app on the watch
     itself (e.g. from Galaxy Store) and sideloading through that, or using
     "Wireless ADB" if the watch supports developer mode over Wi-Fi. Flag
     your exact watch model and I can give more specific steps.

**Important:** this workflow builds the skeleton as-is, with the Samsung SDK
calls left as commented-out TODOs — so it will produce a working *shell* app
right now, before you've added the SDK. Once you get the SDK's AAR file, add
it to the repo's `phone-app/libs/` and `watch-companion/libs/` folders,
uncomment the `implementation files(...)` lines, and fill in the TODOs — then
every push rebuilds real, functioning APKs the same way.

## Next steps once SDK is in hand

1. Drop the SDK jar/aar into both `libs/` folders
2. Fill in the `TODO`s in `SensorStreamService.kt` (phone) and
   `WatchSensorPublisher.kt` (watch) with the real SDK calls per their docs
2. Build watch-companion, install on the Galaxy Fit paired to your phone
3. Build phone-app, install on the phone
4. Launch phone-app — it should discover the watch companion and start
   receiving callbacks
